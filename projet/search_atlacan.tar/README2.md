
                      @autor LE DENMAT Mickael
                      @autor CAMBRESY Florian

                      @version 2.0

                      Groupe TD4: Salle de TD:
                      Jungle - Descart, Mardi matin 9h40 12h50


This archive search_atlacan.tar contains the following files :

- the README2 file you are reading;
- the atlacan.c file, library source that is use in the program;
- the atlacan.h file, library header, describing the functions used in the program;
- the search_atlacan.c file, where are wrote the functions to solve the program. Comment and uncomment the function you want to use in the main of the search_atlacan.c file.
- the Makefile file, where are the commands to compile the program and delete the executable.

To start the program properly do a "make start".
