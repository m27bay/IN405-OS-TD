# td11 Memory managment
 td11 IN405 OS

# Desciption
Memory managment, first implementation and first algorithm( LRU )

## Contains
 - README.md
 - makefile
 - libiof.a
 - memory.cfg
 - memory2.cfg
 - memory3.cfg
 - types.h
 - se_ficher.h
 - memory.c

# Usage
tou can compile the program with three different files.
the first, the default file, with this parameters:
```cfg
4 4096 256 10 100
```
the second, with this paramaters:
```cfg
4 4096 10 10 100
```
And the last but not the least, with this paramaters:
```cfg
4 4096 256 300 200
```

To compile: you have juste to type:
```Bash
make run  # To compile with the first file
make run2 # To compile with the second file
make run3 # To compile with the last file
```

# Author
Le Denmat Mickael, Groupe TD4, Mardi matin 9h40 12h50

## Last update
01/05/20
